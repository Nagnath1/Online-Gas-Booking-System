//
//  RateDistributerViewController.h
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 16/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RateDistributerViewController : UIViewController{
 
    int currentIndex;
}

@property (weak, nonatomic) IBOutlet UISlider *sliderTimelyDelivery;
@property (weak, nonatomic) IBOutlet UISlider *sliderCurrentRate;
@property (weak, nonatomic) IBOutlet UISlider *sliderCorrectWeight;
@property (weak, nonatomic) IBOutlet UISlider *sliderOverallRating;

@property (weak, nonatomic) IBOutlet UILabel *labelTimelyValue;

@property (weak, nonatomic) IBOutlet UILabel *labelRateValue;
@property (weak, nonatomic) IBOutlet UILabel *labelWeightValue;
@property (weak, nonatomic) IBOutlet UILabel *labelOverallValue;

- (IBAction)changeValueTimeDelivery;
- (IBAction)changeValueCurrentRate;
- (IBAction)changeValueWeight;
- (IBAction)changeValueOverall;

- (IBAction)buttonSubmit;
- (IBAction)buttonCancel;

@end
