//
//  LoginViewController.h
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 12/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController :UIViewController{
    BOOL isChecked;
    NSData *data;
}
@property (weak, nonatomic) IBOutlet UITextField *editUsername;
@property (weak, nonatomic) IBOutlet UILabel *editPassword;
@property (weak, nonatomic) IBOutlet UIButton *buttonCheck;

- (IBAction)buttonToggle;
- (IBAction)buttonLogin;
- (IBAction)buttonSignup;

@end
