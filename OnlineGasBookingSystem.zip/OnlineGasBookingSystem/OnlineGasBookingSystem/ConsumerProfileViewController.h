//
//  ConsumerProfileViewController.h
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 16/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ConsumerProfileViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *consumerNo;
@property (weak, nonatomic) IBOutlet UILabel *consumerName;
@property (weak, nonatomic) IBOutlet UILabel *consumerAddress;
@property (weak, nonatomic) IBOutlet UILabel *consumerEmail;
@property (weak, nonatomic) IBOutlet UILabel *consumerMobile;
@property (weak, nonatomic) IBOutlet UILabel *consumerPan;
@property (weak, nonatomic) IBOutlet UILabel *consumerAadhar;

@end
