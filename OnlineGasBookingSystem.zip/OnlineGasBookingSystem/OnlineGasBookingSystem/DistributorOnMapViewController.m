//
//  DistributorOnMapViewController.m
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 18/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import "DistributorOnMapViewController.h"
#import "MyAnnotation.h"
#import <MapKit/MapKit.h>

@interface DistributorOnMapViewController ()

@end

@implementation DistributorOnMapViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title=@"Locate Distributor";
    
    self.locationManager = [[CLLocationManager alloc] init];
    self.locationManager.delegate = self;
    [self.locationManager startUpdatingLocation];
    
    self.mapView.delegate = self;
    
    MyAnnotation *distributorAnnotation = [[MyAnnotation alloc] initLatitude:17.659919 withLongitude:75.906391 withTitle:@"Distributor" withSubtitle:@"Preshak Indane" withImageName:@"Marker.png"];
    [self.mapView addAnnotation:distributorAnnotation];
    
}

#pragma mark - mapview methods

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation {
    
    MyAnnotation *myAnnotation = (MyAnnotation *)annotation;
    
    MKAnnotationView *annotationView = [[MKAnnotationView alloc] init];
    annotationView.image = [UIImage imageNamed:myAnnotation.imageName];
    annotationView.canShowCallout = YES;
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
    annotationView.rightCalloutAccessoryView = button;
    
    UIImageView *imageView = [[UIImageView alloc] init];
    imageView.frame = CGRectMake(0, 0, 20, 20);
    imageView.image = [UIImage imageNamed:@"Marker.png"];
    annotationView.leftCalloutAccessoryView = imageView;
    
    return annotationView;
}

- (void)mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)view calloutAccessoryControlTapped:(UIControl *)control {
    
    MyAnnotation *myAnnotation = (MyAnnotation *) view.annotation;
    
    NSString *message = [NSString stringWithFormat:@"Selected annotation: %@", myAnnotation.title];
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"tapped" message:message delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end
