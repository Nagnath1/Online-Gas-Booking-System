//
//  AboutUsViewController.m
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 22/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import "AboutUsViewController.h"
#import "Utils.h"
#import "HomeViewController.h"

@interface AboutUsViewController ()

@end

@implementation AboutUsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (IBAction)buttonOk {
    
    //HomeViewController *HomeVC = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"HomeVC"];
    //[self presentViewController:HomeVC animated:YES completion:nil];
}

@end
