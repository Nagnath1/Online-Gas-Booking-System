//
//  ConsumerProfileViewController.m
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 16/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import "ConsumerProfileViewController.h"
#import "Constants.h"
#import "Utils.h"
#import "ConsumerProfile.h"
#import "MFSideMenu.h"
@interface ConsumerProfileViewController ()<NSURLConnectionDataDelegate>{
    NSMutableData *container;
    ConsumerProfile *consumerProfile;
    NSData *dataParsed;
    NSString *status;  
    
}

@end

@implementation ConsumerProfileViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title=@"Profile";
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *consumerName=[defaults stringForKey:KEY_LOGIN_USERNAME];
    self.consumerName.text=consumerName;
    
    [defaults synchronize];
    
    
    NSString *strUrl = [NSString stringWithFormat:@"%@?user_name=%@", [Utils getURL:SERVLET_CONSUMER_PROFILE],consumerName ];
    NSString *urlTextEscaped = [strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    [self makeServerCallWithUrl:urlTextEscaped];
}       

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)makeServerCallWithUrl:(NSString *)strUrl {
    
    container = [[NSMutableData alloc] init];
    
    NSURL *url= [NSURL URLWithString:strUrl];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    NSURLConnection *connection = [NSURLConnection connectionWithRequest:request delegate:self];
    dataParsed = [NSData dataWithContentsOfURL:url];
    [connection start];
    [self parseResult:dataParsed];
}

#pragma mark - urlconnection methods

- (NSURLRequest *)connection:(NSURLConnection *)connection willSendRequest:(NSURLRequest *)request redirectResponse:(NSURLResponse *)response {
    
    return request;
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    
    [container appendData:dataParsed];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    
    status = [[NSString alloc]initWithData:container encoding:NSASCIIStringEncoding];
    
    [self parseResult:container];
}

- (void)parseResult:(NSData *)data {
    NSArray *tempOrder = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
    NSLog(@"%@", tempOrder);
    
    for (NSDictionary *dictionary in tempOrder) {
        
        consumerProfile = [[ConsumerProfile alloc] init];
        consumerProfile.number = [dictionary objectForKey:@"consumerNumber"];
        consumerProfile.name = [dictionary objectForKey:@"consumerName"];
        consumerProfile.email = [dictionary objectForKey:@"consumerEmail"];
        consumerProfile.mobile = [dictionary objectForKey:@"consumerMobile"];
        consumerProfile.address = [dictionary objectForKey:@"consumerAddress"];
        consumerProfile.panNo=[dictionary objectForKey:@"consumerPanNo"];
        consumerProfile.aadharNo=[dictionary objectForKey:@"consumerAadharNo"];
        
    }
    self.consumerNo.text=consumerProfile.number;
    self.consumerName.text=consumerProfile.name;
    self.consumerEmail.text=consumerProfile.email;
    self.consumerMobile.text=consumerProfile.mobile;
    self.consumerAddress.text=consumerProfile.address;
    self.consumerPan.text=consumerProfile.panNo;
    self.consumerAadhar.text=consumerProfile.aadharNo;
}



@end
