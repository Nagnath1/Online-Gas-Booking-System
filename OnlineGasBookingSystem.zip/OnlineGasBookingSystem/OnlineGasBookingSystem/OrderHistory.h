//
//  OrderHistory.h
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 18/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OrderHistory : NSObject

@property (nonatomic) NSString *orderNumber;
@property (nonatomic) NSString *orderDate;
@property (nonatomic) NSString *deliveryDate;
@property (nonatomic) NSString *status;

- (instancetype)initWithOrderNumber:(NSString *)orderNumber
                    withOrderDate:(NSString *)orderDate withDeliveryDate:(NSString *)deliveryDate withStatus:(NSString *)status;

@end
