//
//  DetailsTableViewCell.m
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 14/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import "DetailsTableViewCell.h"

@implementation DetailsTableViewCell

- (void)awakeFromNib {
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

@end
