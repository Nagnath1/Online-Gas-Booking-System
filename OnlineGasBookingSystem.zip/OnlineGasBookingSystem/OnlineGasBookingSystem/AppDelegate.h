//
//  AppDelegate.h
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 12/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LoginViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>{
    LoginViewController *loginViewController;
    UINavigationController *navigationController;
}

@property (strong, nonatomic) UIWindow *window;

-(void)showHomeNavigation;
-(void)showLoginViewController;
@end

