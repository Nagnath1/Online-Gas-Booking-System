//
//  Deatils.m
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 14/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import "Deatils.h"

@implementation Deatils

- (instancetype)initWithMenuTitle:(NSString *)menuTitle
                    withImageMenu:(NSString *)imageMenu withViewId:(int)viewControllerId{
    self = [super init];
    if (self) {        
        self.menuTitle = menuTitle;
        self.imageMenu = imageMenu;
        self.viewControllerId= viewControllerId;
    }
    return self;
}
@end
