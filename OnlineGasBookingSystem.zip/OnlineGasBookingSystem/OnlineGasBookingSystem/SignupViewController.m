//
//  SignupViewController.m
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 13/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import "SignupViewController.h"
#import "Utils.h"
#import "Constants.h"

@interface SignupViewController ()

@end

@implementation SignupViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    isChecked=NO;

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
   }

- (IBAction)buttonSubmit {
    
    if([self.editConsumerNo.text length]==0){
        [Utils showAlert:@"Please enter consumer no."];
        
    } else if ([self.editLpgId.text length]== 0) {
        [Utils showAlert:@"Please enter LPG Id"];
        
    }else if ([self.editUsername.text length]== 0) {
        [Utils showAlert:@"Please enter user name"];
        
    }else if ([self.editPassword.text length]== 0) {
        [Utils showAlert:@"Please enter password"];
        
    }else if ([self.editEmail.text length]== 0) {
        [Utils showAlert:@"Please enter email"];
        
    }else if ([self.editAddress.text length]== 0) {
        [Utils showAlert:@"Please enter address"];
        
    }else if ([self.editMobile.text length]== 0) {
        [Utils showAlert:@"Please enter mobile"];
        
    }else if ([self.editPancard.text length]== 0) {
        [Utils showAlert:@"Please enter pan card"];
        
    }else if ([self.editAadhar.text length]== 0) {
        [Utils showAlert:@"Please enter Adhar No."];
        
    }else{
        
        NSString *strUrl = [NSString stringWithFormat:@"%@?consumer_no=%@&LPGId=%@&user_name=%@&password=%@&email=%@&address=%@&mobile=%@&pan_no=%@&aadhar_no=%@", [Utils getURL:SERVLET_REGISTER],self.editConsumerNo.text,self.editLpgId.text,self.editUsername.text, self.editPassword.text,self.editEmail.text,self.editAddress.text,self.editMobile.text,self.editPancard.text,self.editAadhar.text ] ;
        
        //localhost:9090/OnlineGasBooking/RegisterServlet? consumer_no=CX54568&LPGId=54685135&user_name=mayu&password=mayu&email=mayu@gmail.com&address=Pune&pan_no=CGPWD45Q&aadhar_no=6800014646
        NSString* encodedString = [strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] ;
        
        NSURL *url = [NSURL URLWithString:encodedString];
        NSData *data = [NSData dataWithContentsOfURL:url];
        result = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
        [Utils showAlert:@"Registration Successful.."];
        [self dismissViewControllerAnimated:YES completion:nil];
           }
}
- (IBAction)buttonToggle {
    if(isChecked) {
        isChecked = NO;
        [self.buttonCheck setImage:[UIImage imageNamed:@"unchecked Checkbox-64.png"] forState:UIControlStateNormal];
    } else {
        isChecked = YES;
        [self.buttonCheck setImage:[UIImage imageNamed:@"checked Checkbox-64.png"] forState:UIControlStateNormal];
        if ([result isEqualToString:@"-1"]) {
            [Utils showAlert:@"You can not use this user name"];
        } else if ([result isEqualToString:@"0"]) {
            [self dismissViewControllerAnimated:YES completion:nil];
        }
    }
}

- (IBAction)buttonAgree {
    
    UIActionSheet *actionSheetAgree=[[UIActionSheet alloc] initWithTitle:@"(1) You will keep your username and password safe, and won't share them with anyone.(2) You will not pass yourself off as someone else or create multiple, false accounts." delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles: nil];
     [actionSheetAgree showInView:self.view];
    
}

- (IBAction)buttonCancel {
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
