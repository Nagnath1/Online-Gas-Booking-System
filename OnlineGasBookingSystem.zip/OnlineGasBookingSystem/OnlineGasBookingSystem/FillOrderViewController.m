//
//  FillOrderViewController.m
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 15/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import "FillOrderViewController.h"
#import "FillOrder.h"
#import "Constants.h"
#import "Utils.h"
@interface FillOrderViewController ()<NSURLConnectionDataDelegate>{

    NSMutableData *container;
    FillOrder *fillOrder;
    NSData *dataParsed;
    NSString *status;
    NSURL *url;
    NSString* urlTextEscaped;
}
@end

@implementation FillOrderViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title=@"LPG Refill Order";
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *consumerName=[defaults stringForKey:KEY_LOGIN_USERNAME];
    self.consumerName.text=consumerName;
    
    [defaults synchronize];
    
    
    NSString *strUrl = [NSString stringWithFormat:@"%@?user_name=%@", [Utils getURL:SERVLET_ORDER_NOW],consumerName ];
    urlTextEscaped = [strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];

    [self makeServerCallWithUrl:strUrl];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
- (void)makeServerCallWithUrl:(NSString *)strUrl {
    
    container = [[NSMutableData alloc] init];
    
    url= [NSURL URLWithString:urlTextEscaped];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    NSURLConnection *connection = [NSURLConnection connectionWithRequest:request delegate:self];
    dataParsed = [NSData dataWithContentsOfURL:url];
    [connection start];
    [self parseResult:dataParsed];
}


#pragma mark - urlconnection methods

- (NSURLRequest *)connection:(NSURLConnection *)connection willSendRequest:(NSURLRequest *)request redirectResponse:(NSURLResponse *)response {
    
    return request;
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    [container appendData:dataParsed];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    
    status = [[NSString alloc]initWithData:container encoding:NSASCIIStringEncoding];
    
    [self parseResult:container];
}

- (void)parseResult:(NSData *)data {
    NSArray *tempOrder = [NSJSONSerialization JSONObjectWithData:dataParsed options:NSJSONReadingMutableContainers error:nil];
    NSLog(@"%@", tempOrder);
    
    for (NSDictionary *dictionary in tempOrder) {
        
        fillOrder = [[FillOrder alloc] init];
        fillOrder.consumerNumber = [dictionary objectForKey:@"consumerNumber"];
        fillOrder.consumerName = [dictionary objectForKey:@"consumerName"];
        fillOrder.consumerEmail = [dictionary objectForKey:@"consumerEmail"];
        fillOrder.consumerMobile = [dictionary objectForKey:@"consumerMobile"];
        fillOrder.consumerAddress = [dictionary objectForKey:@"consumerAddress"];
        
    }
    self.consumerId.text=fillOrder.consumerNumber;
    self.consumerEmail.text=fillOrder.consumerEmail;
    self.consumerMobile.text=fillOrder.consumerMobile;
    self.consumerAddress.text=fillOrder.consumerAddress;
}



- (IBAction)buttonOrderNow {
    
    [Utils showAlert:@"Your booking is successful..."];
    
    
    NSString *insertStatus=@"progress";
    
    //Date
    
    NSDate *date = [NSDate date];
    int daysToAdd = 3;
    NSDate *deliveryDate = [date dateByAddingTimeInterval:60*60*24*daysToAdd];
    
    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd-MM-YYYY"];
    NSLog(@"%@",[dateFormatter stringFromDate:[NSDate date]]);
    
    NSString *orderDate=[dateFormatter stringFromDate:[NSDate date]];
    NSString *deliveryDateFormat=[dateFormatter stringFromDate:deliveryDate];
    
    NSString *insertUrl = [NSString stringWithFormat:@"%@?&user_name=%@&order_date=%@&delivery_date=%@&order_status=%@", [Utils getURL:SERVLET_INSERT_ORDER],fillOrder.consumerName,orderDate,deliveryDateFormat,insertStatus ] ;
    
    NSString *orderInsert = [insertUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *inserturl = [NSURL URLWithString:orderInsert];
    
    NSData *insertData = [NSData dataWithContentsOfURL:inserturl];
    insertResult = [[NSString alloc] initWithData:insertData encoding:NSASCIIStringEncoding];
    [self.navigationController popToRootViewControllerAnimated:YES ];
}
@end
