//
//  SignupViewController.h
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 13/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignupViewController : UIViewController<UIActionSheetDelegate>{
    BOOL isChecked;
    NSString *result;
}

- (IBAction)buttonSubmit;
- (IBAction)buttonToggle;
- (IBAction)buttonAgree;
- (IBAction)buttonCancel;

@property (weak, nonatomic) IBOutlet UIButton *buttonCheck;

@property (weak, nonatomic) IBOutlet UITextField *editConsumerNo;
@property (weak, nonatomic) IBOutlet UITextField *editLpgId;
@property (weak, nonatomic) IBOutlet UITextField *editUsername;
@property (weak, nonatomic) IBOutlet UITextField *editPassword;
@property (weak, nonatomic) IBOutlet UITextField *editEmail;
@property (weak, nonatomic) IBOutlet UITextField *editAddress;
@property (weak, nonatomic) IBOutlet UITextField *editMobile;
@property (weak, nonatomic) IBOutlet UITextField *editPancard;
@property (weak, nonatomic) IBOutlet UITextField *editAadhar;

@property (weak, nonatomic) IBOutlet UILabel *labelText;
@property (weak, nonatomic) IBOutlet UIButton *labelSumbmit;


@end
