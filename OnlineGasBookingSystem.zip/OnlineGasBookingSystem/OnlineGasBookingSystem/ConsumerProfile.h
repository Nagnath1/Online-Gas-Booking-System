//
//  ConsumerProfile.h
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 19/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ConsumerProfile : NSObject
@property (nonatomic) NSString *name;
@property (nonatomic) NSString *number;
@property (nonatomic) NSString *address;
@property (nonatomic) NSString *mobile;
@property (nonatomic) NSString *email;
@property (nonatomic) NSString * panNo;
@property (nonatomic) NSString *aadharNo;
@end
