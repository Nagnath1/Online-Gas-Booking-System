//
//  HomeViewController.h
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 15/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface HomeViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray *details;
    int fillOrderId;
    int REFillHistoryId;
}

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UILabel *labelUserName;

@end
