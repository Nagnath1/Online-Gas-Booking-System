//
//  TalkUsViewController.h
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 16/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TalkUsViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *editSubject;
@property (weak, nonatomic) IBOutlet UITextView *editComment;
@property (weak, nonatomic) IBOutlet UITextField *editEmail;

- (IBAction)buttonSumbit;

@end
