//
//  ContactInfoViewController.h
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 16/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContactInfoViewController : UIViewController

- (IBAction)ButtonViewOnMap;


@end
