//
//  RateDistributerViewController.m
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 16/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import "RateDistributerViewController.h"
#import "MFSideMenu.h"
#import "Utils.h"
#import "Constants.h"

@interface RateDistributerViewController (){
    NSString *userName;
}

@end

@implementation RateDistributerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    userName=[defaults stringForKey:KEY_LOGIN_USERNAME];
    
    self.navigationItem.title=@"Rate Distributor";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (IBAction)changeValueTimeDelivery{
    
    if(self.sliderTimelyDelivery.value==0){
        [Utils showAlert:@"Please give rating bar for Timely Delivery"];
    }else{
        
        self.labelTimelyValue.text = [NSString stringWithFormat:@"%d", (int)self.sliderTimelyDelivery.value];
    }
}
- (IBAction)changeValueCurrentRate{
   
     self.labelRateValue.text = [NSString stringWithFormat:@"%d", (int)self.sliderCurrentRate.value];
    
}
- (IBAction)changeValueWeight{
    
        self.labelWeightValue.text = [NSString stringWithFormat:@"%d", (int)self.sliderCorrectWeight.value];
    
}
- (IBAction)changeValueOverall{
    
    self.labelOverallValue.text = [NSString stringWithFormat:@"%d", (int)self.sliderOverallRating.value];
   
}

- (IBAction)buttonSubmit {
    
    NSString *strUrl = [NSString stringWithFormat:@"%@?user_name=%@&timely_delivery=%@&correct_rate=%@&correct_weight=%@&overall_rating=%@", [Utils getURL:SERVLET_RATING_BAR], userName,self.labelTimelyValue.text,self.labelRateValue.text,self.labelWeightValue.text,self.labelOverallValue.text] ;
    
    //localhost:9090/OnlineGasBooking/RegisterServlet? consumer_no=CX54568&LPGId=54685135&user_name=mayu&password=mayu&email=mayu@gmail.com&address=Pune&pan_no=CGPWD45Q&aadhar_no=6800014646
    NSString* encodedString = [strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] ;
    NSURL *url = [NSURL URLWithString:encodedString];
    NSData *data = [NSData dataWithContentsOfURL:url];
    NSString *result = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
    [Utils showAlert:@"Thank u for your rating.."];
        
    [self.navigationController popToRootViewControllerAnimated:YES ];
}

- (IBAction)buttonCancel {
    
    [self.navigationController popViewControllerAnimated:YES];
}

@end
