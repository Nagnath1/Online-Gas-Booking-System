//
//  LoginViewController.m
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 12/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import "LoginViewController.h"
#import "SignupViewController.h"
#import "HomeViewController.h"
#import "Utils.h"
#import "Constants.h"
#import "AppDelegate.h"
@interface LoginViewController ()

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

-(void)viewWillAppear:(BOOL)animated{
    self.editUsername.text=nil;
    self.editPassword.text=nil;
    self.navigationController.navigationBarHidden=YES;
}

-(void)viewWillDisappear:(BOOL)animated{
    self.navigationController.navigationBarHidden=NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (IBAction)buttonToggle {
    if(isChecked) {
        isChecked = NO;
        [self.buttonCheck setImage:[UIImage imageNamed:@"unchecked Checkbox-64.png"] forState:UIControlStateNormal];
    } else {
        isChecked = YES;
        [self.buttonCheck setImage:[UIImage imageNamed:@"checked Checkbox-64.png"] forState:UIControlStateNormal];
        
        }
}

- (IBAction)buttonLogin {
    
    if([self.editUsername.text length]==0){
        [Utils showAlert:@"Please enter name"];
        
     } else if ([self.editPassword.text length]== 0) {
     [Utils showAlert:@"Please enter password"];
     
     }else if(isChecked==YES) {
        NSString *userName = self.editUsername.text;
         
         
        NSString *password = self.editPassword.text;
        
        NSString *url = [NSString stringWithFormat:@"%@?user_name=%@&password=%@", [Utils getURL:SERVLET_LOGIN], userName, password];
        NSString* urlTextEscaped = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSURL *url1 = [NSURL URLWithString:urlTextEscaped];
         
        data = [NSData dataWithContentsOfURL:url1];
        
         NSError *error;
         NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
         
        NSString *status=[dictionary valueForKey:@"status"];
         
        if ([status isEqualToString:@"failure"])
        {
            [Utils showAlert:@"Invalid user name or password"];
        } else if ([status isEqualToString:@"success"]){            
            
            NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
            [defaults setBool:YES forKey:KEY_LOGIN_STATUS];
            [defaults setValue:[dictionary valueForKey:@"userId"] forKey:KEY_LOGIN_USERID];
            [defaults setValue:[dictionary valueForKey:@"Username"] forKey:KEY_LOGIN_USERNAME];
            
            [defaults synchronize];
           
            AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
            [appDelegate showHomeNavigation];           
            
        }
    }
}

- (IBAction)buttonSignup {
    SignupViewController *svc=[[UIStoryboard storyboardWithName:@"Main" bundle:nil]instantiateViewControllerWithIdentifier:@"SignupVC"];
    [self presentViewController:svc animated:YES completion:nil];

    
}
@end
