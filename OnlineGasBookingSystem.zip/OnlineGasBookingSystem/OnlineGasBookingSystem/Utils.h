//
//  Utils.h
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 13/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import <Foundation/Foundation.h>

@class UIViewController;
@interface Utils : NSObject

+ (void)showAlert:(NSString *)message;
+ (NSString *)getURL:(NSString *)page;
+ (UIViewController *)instantiateViewControllerWithId:(NSString *)vcId;

@end
