//
//  OrderHistoryTableViewCell.m
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 18/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import "OrderHistoryTableViewCell.h"

@implementation OrderHistoryTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
