//
//  DetailsTableViewCell.h
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 14/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailsTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *labelTitle;
@property (weak, nonatomic) IBOutlet UIImageView *image;

@end
