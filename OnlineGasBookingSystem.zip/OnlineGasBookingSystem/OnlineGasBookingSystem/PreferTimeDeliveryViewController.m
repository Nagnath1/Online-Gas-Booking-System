//
//  PreferTimeDeliveryViewController.m
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 16/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import "PreferTimeDeliveryViewController.h"
#import "Constants.h"
#import "Utils.h"

@interface PreferTimeDeliveryViewController (){
    NSString *userName;
}

@end

@implementation PreferTimeDeliveryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSDictionary *size = [NSDictionary dictionaryWithObjectsAndKeys:[UIFont fontWithName:@"Arial" size:17.0],NSFontAttributeName, nil];
    
    self.navigationController.navigationBar.titleTextAttributes = size;
    self.navigationItem.title=@"Prefered Time Delivery";
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    userName=[defaults stringForKey:KEY_LOGIN_USERNAME];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (IBAction)buttonPreferTime {
    
    NSDateFormatter *outputFormatter1 = [[NSDateFormatter alloc] init];
    [outputFormatter1 setDateFormat:@"HH:mm"]; //24hr time format
    
     NSDateFormatter *outputFormatter2 = [[NSDateFormatter alloc] init];
    [outputFormatter2 setDateFormat:@"DD-MM-YYYY"]; //Date format

    
    NSString *date1=[outputFormatter2 stringFromDate:self.datePicker.date];
    NSString *timeString1 = [outputFormatter1 stringFromDate:self.timePicker1.date];
    NSString *timeString2 = [outputFormatter1 stringFromDate:self.timePicker2.date];
    
    NSString *preferTimeUrl = [NSString stringWithFormat:@"%@?user_name=%@&prefered_date=%@&prefered_time=%@&prefered_time2=%@", [Utils getURL:SERVLET_PREFERED_TIME_DELIVERY], userName, date1, timeString1, timeString2];
    
    NSString* encodedString = [preferTimeUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] ;
    NSURL *url = [NSURL URLWithString:encodedString];
    [NSData dataWithContentsOfURL:url];
    
    [self.navigationController popToRootViewControllerAnimated:YES ];
}
@end
