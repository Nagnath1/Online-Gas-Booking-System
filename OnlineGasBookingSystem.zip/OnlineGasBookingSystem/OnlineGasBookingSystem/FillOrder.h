//
//  FillOrder.h
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 16/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FillOrder : NSObject

@property (nonatomic) NSString *consumerName;
@property (nonatomic) NSString *consumerNumber;
@property (nonatomic) NSString *consumerAddress;
@property (nonatomic) NSString *consumerMobile;
@property (nonatomic) NSString *consumerEmail;
 
@end
