//
//  OrderHistory.m
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 18/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import "OrderHistory.h"

@implementation OrderHistory

- (instancetype)initWithOrderNumber:(NSString *)orderNumber
                      withOrderDate:(NSString *)orderDate withDeliveryDate:(NSString *)deliveryDate withStatus:(NSString *)status{
    self = [super init];
    if (self) {
        self.orderNumber = orderNumber;
        self.orderDate = orderDate;
        self.deliveryDate= deliveryDate;
    }
    return self;
}
@end
