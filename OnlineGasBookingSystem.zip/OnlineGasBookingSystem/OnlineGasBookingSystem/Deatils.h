//
//  Deatils.h
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 14/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Deatils : NSObject


@property (nonatomic) NSString *menuTitle;
@property (nonatomic) NSString *imageMenu;
@property (nonatomic) int viewControllerId;

- (instancetype)initWithMenuTitle:(NSString *)menuTitle
                    withImageMenu:(NSString *)imageMenu withViewId:(int)viewControllerId;
@end
