//
//  RefillOrderHistoryViewController.m
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 16/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import "RefillOrderHistoryViewController.h"
#import "OrderHistoryTableViewCell.h"
#import "OrderHistory.h"
#import "Constants.h"
#import "Utils.h"

@interface RefillOrderHistoryViewController ()<NSURLConnectionDataDelegate>{
    
    NSMutableData *container;
    NSData *dataParsed;
    NSString *consumerName;
    OrderHistory *orderHistory;
    NSString *urlTextEscaped;
}


@end

@implementation RefillOrderHistoryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title=@"Order History";
    
    [self.tableView registerNib:[UINib nibWithNibName:@"OrderHistoryTableViewCell" bundle:nil] forCellReuseIdentifier:@"cell"];
    
    details=[[NSMutableArray alloc] init];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    consumerName=[defaults stringForKey:KEY_LOGIN_USERNAME];
    
    [defaults synchronize];
    
    container = [[NSMutableData alloc] init];
     
     [self fetchDetails];
}

- (void)fetchDetails {
    
    NSString *strUrl = [NSString stringWithFormat:@"%@?consumer_name=%@", [Utils getURL:SERVLET_ORDER_HISTORY],consumerName ];
    urlTextEscaped = [strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];

 [self makeServerCallWithUrl:strUrl];
 
 }
 
- (void)makeServerCallWithUrl:(NSString *)strUrl {
 
  container = [[NSMutableData alloc] init];
    
    NSURL *url= [NSURL URLWithString:urlTextEscaped];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    NSURLConnection *connection = [NSURLConnection connectionWithRequest:request delegate:self];
    dataParsed = [NSData dataWithContentsOfURL:url];
    [connection start];
    [self parseResult:dataParsed];
 }

 #pragma mark - urlconnection methods
 
 - (NSURLRequest *)connection:(NSURLConnection *)connection willSendRequest:(NSURLRequest *)request redirectResponse:(NSURLResponse *)response {
     
 return request;
     
 }

 - (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
     
     [container appendData:data];
     
 }
 
 - (void)connectionDidFinishLoading:(NSURLConnection *)connection {
 
   //NSString *status = [[NSString alloc]initWithData:container encoding:NSASCIIStringEncoding];
 
[self parseResult:container];
 }

 - (void)parseResult:(NSData *)data {
 NSArray *tempOrderHistory = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
   
  [details removeAllObjects];
     
 NSLog(@"%@", tempOrderHistory);
 
 for (NSDictionary *dictionary in tempOrderHistory) {
 
 orderHistory = [[OrderHistory alloc] init];
 orderHistory.orderNumber = [dictionary objectForKey:@"orderNumber"];
 orderHistory.orderDate = [dictionary objectForKey:@"orderDate"];
 orderHistory.deliveryDate = [dictionary objectForKey:@"deliveryDate"];
 orderHistory.status = [dictionary objectForKey:@"Status"];
 
 [details addObject:orderHistory];
     
    }
 }
 
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


#pragma mark - tableView methods

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [details count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    OrderHistoryTableViewCell *cell=[self.tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    orderHistory = [details objectAtIndex:indexPath.row];
    
    cell.orderNumberLabel.text = [NSString stringWithFormat:@"%@", orderHistory.orderNumber];
    cell.OrderDateLabel.text = [NSString stringWithFormat:@"%@", orderHistory.orderDate];
    cell.DeliveryDateLabel.text = [NSString stringWithFormat:@"%@", orderHistory.deliveryDate];
    cell.StatusLabel.text = [NSString stringWithFormat:@"%@", orderHistory.status];
    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 115;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
}
@end
