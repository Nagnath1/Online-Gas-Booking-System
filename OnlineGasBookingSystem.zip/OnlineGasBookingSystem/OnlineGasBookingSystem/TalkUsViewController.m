//
//  TalkUsViewController.m
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 16/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import "TalkUsViewController.h"
#import "Utils.h"
#import "Constants.h"
#import "HomeViewController.h"

@interface TalkUsViewController ()
{
    NSString *talkUsresult;
}
@end

@implementation TalkUsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title=@"Talk Us";
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

- (IBAction)buttonSumbit {
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
     NSString *consumerName=[defaults stringForKey:KEY_LOGIN_USERNAME];
     
     [defaults synchronize];
    
    NSString *talkUsStrUrl = [NSString stringWithFormat:@"%@?user_name=%@&user_email=%@&user_subject=%@&user_comment=%@", [Utils getURL:SERVLET_TALK_US],consumerName,self.editEmail.text,self.editSubject.text,self.editComment.text ];
    
    NSString* encodedString = [talkUsStrUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] ;
    
    NSURL *talkUsUrl=[NSURL URLWithString:encodedString];
    NSData *talkUsData=[NSData dataWithContentsOfURL:talkUsUrl];
    talkUsresult=[[NSString alloc] initWithData:talkUsData encoding:NSASCIIStringEncoding];
    
    HomeViewController *homeViewController=(HomeViewController *)[Utils instantiateViewControllerWithId:@"HomeVC"];
    
    [self.navigationController pushViewController:homeViewController animated:YES];
}

@end
