//
//  OrderHistoryTableViewCell.h
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 18/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OrderHistoryTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *orderNumberLabel;
@property (weak, nonatomic) IBOutlet UILabel *OrderDateLabel;
@property (weak, nonatomic) IBOutlet UILabel *DeliveryDateLabel;
@property (weak, nonatomic) IBOutlet UILabel *StatusLabel;

@end
