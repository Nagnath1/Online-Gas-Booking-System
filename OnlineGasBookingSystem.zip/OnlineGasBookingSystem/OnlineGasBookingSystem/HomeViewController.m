//
//  HomeViewController.m
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 15/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import "HomeViewController.h"
#import "DetailsTableViewCell.h"
#import "Deatils.h"
#import "FillOrderViewController.h"
#import "RefillOrderHistoryViewController.h"
#import "MechanicServiceViewController.h"
#import "PreferTimeDeliveryViewController.h"
#import "ContactInfoViewController.h"
#import "RateDistributerViewController.h"
#import "ConsumerProfileViewController.h"
#import "TalkUsViewController.h"
#import "Utils.h"
#import "Constants.h"
#import "AppDelegate.h"
#import "MFSideMenu.h"
#import "UIViewController+MFSideMenuAdditions.h"

@interface HomeViewController ()

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    fillOrderId=0;
     REFillHistoryId=1;
    
    self.navigationItem.title=@"Home";
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"menu-icon.png"] style:UIBarButtonItemStyleDone target:self action:@selector(toggleLeftVC)];
    
     self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Logout" style:UIBarButtonItemStyleDone target:self action:@selector(logoutUser)];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *userName=[defaults stringForKey:KEY_LOGIN_USERNAME];
    
    self.labelUserName.text=[NSString stringWithFormat:@"Welcome %@",userName];
    
    [defaults synchronize];
    
    details = [[NSMutableArray alloc] init];
    
    [details addObject:[[Deatils alloc]initWithMenuTitle:@"LPGRefillOrder" withImageMenu:@"images.png" withViewId:0]];
    [details addObject:[[Deatils alloc]initWithMenuTitle:@"Refill Order History" withImageMenu:@"1451575056365.png" withViewId:1]];
    [details addObject:[[Deatils alloc]initWithMenuTitle:@"Mechanic Service" withImageMenu:@"images-3.jpeg" withViewId:2]];
    [details addObject:[[Deatils alloc]initWithMenuTitle:@"Prefer Time Delivery" withImageMenu:@"banner7.jpg" withViewId:3]];
    [details addObject:[[Deatils alloc]initWithMenuTitle:@"Imp Contact Info" withImageMenu:@"images-2.png" withViewId:4]];
    [details addObject:[[Deatils alloc]initWithMenuTitle:@"Rate Distributor" withImageMenu:@"Oxygen-Icons.org-Oxygen-Actions-rating-2.ico" withViewId:5]];
    [details addObject:[[Deatils alloc]initWithMenuTitle:@"Consumer Profile" withImageMenu:@"user_customer.png" withViewId:6]];
    [details addObject:[[Deatils alloc]initWithMenuTitle:@"Talk Us" withImageMenu:@"2a1d82d.jpg" withViewId:7]];
    
    [self.tableView setRowHeight:80];
    
    [self.tableView registerNib:[UINib nibWithNibName:@"DetailsTableViewCell" bundle:nil] forCellReuseIdentifier:@"cell"];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}
- (void) toggleLeftVC {
    [self.menuContainerViewController toggleLeftSideMenuCompletion:^{
        //[self setupMenuBarButtonItems];

    }];
}
#pragma mark -tableView

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [details count];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 80;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    DetailsTableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"cell"];

    Deatils *detail = [details objectAtIndex:indexPath.row];
    
    cell.labelTitle.text = [NSString stringWithFormat:@"%@", detail.menuTitle];
    cell.image.image = [UIImage imageNamed:detail.imageMenu];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    FillOrderViewController *fvc = (FillOrderViewController *)  [Utils instantiateViewControllerWithId:@"FillOrderVC"];
   
    RefillOrderHistoryViewController *rvc=(RefillOrderHistoryViewController *)[Utils instantiateViewControllerWithId:@"RefillOrderVC"];
    
    MechanicServiceViewController *mvc=(MechanicServiceViewController *)[Utils instantiateViewControllerWithId:@"MechanicServiceVC"];
    
    PreferTimeDeliveryViewController *pvc=(PreferTimeDeliveryViewController *)[Utils instantiateViewControllerWithId:@"PreferTimedeliveryVC"];
    
    ContactInfoViewController *cvc=(ContactInfoViewController *)[Utils instantiateViewControllerWithId:@"ContactInfoVC"];
    
    RateDistributerViewController *ratevc=(RateDistributerViewController *)[Utils instantiateViewControllerWithId:@"RateDistributerVC"];
    
    ConsumerProfileViewController *consumervc=(ConsumerProfileViewController *)[Utils instantiateViewControllerWithId:@"ConsumerProfileVC"];
    TalkUsViewController *tvc=(TalkUsViewController *)[Utils instantiateViewControllerWithId:@"TalkusVC"];
    
    Deatils *detail = [details objectAtIndex:indexPath.row];
    
    if(detail.viewControllerId==0){
        [self.navigationController pushViewController:fvc animated:YES];
    }
    else if (detail.viewControllerId==1)
    {
        [self.navigationController pushViewController:rvc animated:YES];
    }else if (detail.viewControllerId==2)
    {
        [self.navigationController pushViewController:mvc animated:YES];
    }else if (detail.viewControllerId==3)
    {
        [self.navigationController pushViewController:pvc animated:YES];
    }else if (detail.viewControllerId==4)
    {
        [self.navigationController pushViewController:cvc animated:YES];
    }else if (detail.viewControllerId==5)
    {
        [self.navigationController pushViewController:ratevc animated:YES];
    }else if (detail.viewControllerId==6)
    {
        [self.navigationController pushViewController:consumervc animated:YES];
    }else if (detail.viewControllerId==7)
    {
        [self.navigationController pushViewController:tvc animated:YES];
    }
    
}

- (IBAction)logoutUser {
    
     UIAlertView *alert = [[UIAlertView alloc] init];
     [alert setTitle:@"Please Confirm"];
     [alert setMessage:@"are you sure?"];
     [alert setDelegate:self];
     [alert addButtonWithTitle:@"Yes"];
     [alert addButtonWithTitle:@"No"];
     [alert show];
    
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0)
    {
        // Yes, do something
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        [defaults setBool:NO forKey:KEY_LOGIN_STATUS];
        [defaults synchronize];
        
        AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
        [appDelegate showLoginViewController];
    }
    else if (buttonIndex == 1)
    {
        // No
    }
}
@end
