//
//  AppDelegate.m
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 12/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import "AppDelegate.h"
#import "LoginViewController.h"
#import "Constants.h"
#import "Utils.h"
#import "HomeViewController.h"
#import "LeftMenuViewController.h"
#import "MFSideMenuContainerViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
      loginViewController = (LoginViewController *) [Utils instantiateViewControllerWithId:@"LoginVC"];
     
     navigationController = (UINavigationController *)[Utils instantiateViewControllerWithId:@"HomeNav"];
     
     NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
     if ([defaults boolForKey:KEY_LOGIN_STATUS]) {
         [self showHomeNavigation];
     } else {
     self.window.rootViewController = loginViewController;
     }
    
    
    
    return YES;

}

-(void)showHomeNavigation{
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    LeftMenuViewController *leftVC = [storyBoard instantiateViewControllerWithIdentifier:@"leftVC"];
    
    HomeViewController *homeVC = [storyBoard instantiateViewControllerWithIdentifier:@"HomeVC"];
    
    navigationController = [[UINavigationController alloc] initWithRootViewController:homeVC];
    
    MFSideMenuContainerViewController *vc = [MFSideMenuContainerViewController containerWithCenterViewController:navigationController leftMenuViewController:leftVC rightMenuViewController:nil];
    
    self.window.rootViewController = vc;
}


-(void)showLoginViewController{
    self.window.rootViewController=loginViewController;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
