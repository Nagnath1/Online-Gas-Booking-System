//
//  Utils.m
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 13/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import "Utils.h"
#import <UIKit/UIKit.h>
#import "Constants.h"

@implementation Utils

+ (void)showAlert:(NSString *)message {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:message delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
}

+ (NSString *)getURL:(NSString *)page {
    return [NSString stringWithFormat:@"%@/%@", SERVER_URL, page];
}                            

+ (UIViewController *)instantiateViewControllerWithId:(NSString *)vcId {
    return [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:vcId];
}
@end
