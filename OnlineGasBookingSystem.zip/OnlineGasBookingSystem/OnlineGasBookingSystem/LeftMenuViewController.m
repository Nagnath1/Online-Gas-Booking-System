//
//  LeftMenuViewController.m
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 18/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import "LeftMenuViewController.h"
#import "MFSideMenu.h"
#import "HomeViewController.h"
#import "ConsumerProfileViewController.h"
#import "Option.h"
#import "SideBarTableViewCell.h"

@interface LeftMenuViewController ()

@end

@implementation LeftMenuViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    options = [[NSMutableArray alloc] init];
    
    [options addObject:[[Option alloc]initWithMenuTitle:@"Home" withImageMenu:@"Home.png"]];
    [options addObject:[[Option alloc]initWithMenuTitle:@"Profile" withImageMenu:@"Profile.png"]];
    [options addObject:[[Option alloc]initWithMenuTitle:@"Contact Distributor" withImageMenu:@"Contact_Card_Filled.png"]];
    [options addObject:[[Option alloc]initWithMenuTitle:@"About US" withImageMenu:@"Info-52.png"]];
    //[options addObject:[[Option alloc]initWithMenuTitle:@"Logout" withImageMenu:@"Logout.png"]];
    
    [self.sideBarTableView setRowHeight:45];
    
    [self.sideBarTableView registerNib:[UINib nibWithNibName:@"SideBarTableViewCell" bundle:nil] forCellReuseIdentifier:@"cell"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark - tableView

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [options count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    SideBarTableViewCell *cell = [self.sideBarTableView dequeueReusableCellWithIdentifier:@"cell"];
    
    Option *option = [options objectAtIndex:indexPath.row];
    cell.labelMenu.text = [NSString stringWithFormat:@"%@", option.menuTitle];
    cell.image.image = [UIImage imageNamed:option.imageOption];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
 [self.sideBarTableView deselectRowAtIndexPath:indexPath animated:YES];
 
 NSString *vcIdentifier = nil;
 if (indexPath.row == 0) {
 vcIdentifier = @"HomeVC";
 } else if (indexPath.row == 1) {
 vcIdentifier = @"ConsumerProfileVC";
 } else if (indexPath.row == 2) {
 vcIdentifier = @"ContactInfoVC";
 }
 else if (indexPath.row == 3) {
     vcIdentifier = @"AboutUsVC";
     
 }
 
 HomeViewController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:vcIdentifier];
  
 UINavigationController *navigationController = self.menuContainerViewController.centerViewController;
    
 NSArray *controllers = [NSArray arrayWithObject:vc];
 navigationController.viewControllers = controllers;
    
 [self.menuContainerViewController setMenuState:MFSideMenuStateClosed];
    
 }

@end
