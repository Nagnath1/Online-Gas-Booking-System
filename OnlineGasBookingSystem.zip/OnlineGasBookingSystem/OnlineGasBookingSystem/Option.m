//
//  Option.m
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 22/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import "Option.h"

@implementation Option

- (instancetype)initWithMenuTitle:(NSString *)menuTitle
                    withImageMenu:(NSString *)imageOption{
    self = [super init];
    if (self) {
        self.menuTitle = menuTitle;
        self.imageOption = imageOption;
    }
    return self;
}

@end
