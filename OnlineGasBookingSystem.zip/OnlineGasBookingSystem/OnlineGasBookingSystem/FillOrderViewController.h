//
//  FillOrderViewController.h
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 15/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FillOrderViewController : UIViewController{
    NSString *insertResult;
}

- (void)makeServerCallWithUrl:(NSString *)strUrl;
- (void)parseResult:(NSData *)data;
@property (weak, nonatomic) IBOutlet UILabel *consumerName;
@property (weak, nonatomic) IBOutlet UILabel *consumerId;
@property (weak, nonatomic) IBOutlet UILabel *consumerAddress;
@property (weak, nonatomic) IBOutlet UILabel *consumerMobile;
@property (weak, nonatomic) IBOutlet UILabel *consumerEmail;
- (IBAction)buttonOrderNow;

@property (nonatomic) int fillOrderId;
@end
