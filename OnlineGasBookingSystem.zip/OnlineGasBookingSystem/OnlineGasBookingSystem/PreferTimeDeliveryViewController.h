//
//  PreferTimeDeliveryViewController.h
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 16/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PreferTimeDeliveryViewController : UIViewController
- (IBAction)buttonPreferTime;
@property (weak, nonatomic) IBOutlet UIDatePicker *datePicker;
@property (weak, nonatomic) IBOutlet UIDatePicker *timePicker1;
@property (weak, nonatomic) IBOutlet UIDatePicker *timePicker2;
@end
