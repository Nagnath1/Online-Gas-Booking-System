//
//  ContactInfoViewController.m
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 16/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import "ContactInfoViewController.h"
#import "DistributorOnMapViewController.h"
#import "Utils.h"
#import "MFSideMenu.h"

@interface ContactInfoViewController ()

@end

@implementation ContactInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title=@"Imp Contact Info";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (IBAction)ButtonViewOnMap {
    
     DistributorOnMapViewController *mapVC=(DistributorOnMapViewController *)[Utils instantiateViewControllerWithId:@"distributorOnMapVC"];
    
    [self.navigationController pushViewController:mapVC animated:YES];
}
@end
