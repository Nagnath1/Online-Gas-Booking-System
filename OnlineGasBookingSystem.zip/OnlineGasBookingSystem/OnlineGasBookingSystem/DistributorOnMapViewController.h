//
//  DistributorOnMapViewController.h
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 18/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface DistributorOnMapViewController : UIViewController<MKMapViewDelegate, CLLocationManagerDelegate>

@property (nonatomic) CLLocationManager *locationManager;

@property (weak, nonatomic) IBOutlet MKMapView *mapView;


@end
