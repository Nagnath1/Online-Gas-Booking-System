//
//  SideBarTableViewCell.h
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 21/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SideBarTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *image;
@property (weak, nonatomic) IBOutlet UILabel *labelMenu;

@end
