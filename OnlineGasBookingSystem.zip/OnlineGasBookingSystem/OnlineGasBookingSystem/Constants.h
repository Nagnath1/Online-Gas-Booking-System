//
//  Constants.h
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 13/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//
#ifndef Constants_h
#define Constants_h

#define SERVER_URL @"http://172.0.1.95:9090/OnlineGasBooking"

#define KEY_LOGIN_STATUS @"KEY_LOGIN_STATUS"
#define KEY_LOGIN_USERID @"KEY_LOGIN_USERID"
#define KEY_LOGIN_USERNAME @"KEY_LOGIN_USERNAME"

#define SERVLET_REGISTER @"RegisterServlet"
#define SERVLET_LOGIN @"LoginServlet"
#define SERVLET_ORDER_NOW @"OrderNowServlet"
#define SERVLET_INSERT_ORDER @"InsertOrderServlet"
#define SERVLET_CONSUMER_PROFILE @"ConsumerProfileServlet"
#define SERVLET_TALK_US @"TalkUsServlet"
#define SERVLET_ORDER_HISTORY @"OrderHistoryServlet"
#define SERVLET_RATING_BAR @"RatingServlet"
#define SERVLET_PREFERED_TIME_DELIVERY @"PreferedDateServlet"

#endif /* Constants_h */

