//
//  ConsumerProfile.m
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 19/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import "ConsumerProfile.h"

@implementation ConsumerProfile

@end
