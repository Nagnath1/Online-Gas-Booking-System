//
//  Option.h
//  OnlineGasBookingSystem
//
//  Created by sunbeam on 22/01/16.
//  Copyright (c) 2016 sunbeam. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Option : NSObject

@property (nonatomic) NSString *menuTitle;
@property (nonatomic) NSString *imageOption;

- (instancetype)initWithMenuTitle:(NSString *)menuTitle
                    withImageMenu:(NSString *)imageOption;

@end
